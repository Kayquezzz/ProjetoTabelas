import streamlit as st
import pandas as pd

# Título do app
st.title('Análise de Alunos por Estado, Idade, Origem e Escolaridade')

try:
    # Lendo o arquivo CSV (local)
    df = pd.read_csv('alunos_pii_none.csv')

    # --- Análise 1: Alunos por Cidade ---
    st.header('Estados com mais discrêpancia de alunos')
    if 'Cidade de Correspondência' in df.columns:
        alunos_por_cidade = df['Cidade de Correspondência'].value_counts().head(5)
        idade_media_cidade = df.groupby('Cidade de Correspondência')['Idade'].mean().loc[alunos_por_cidade.index]

        cidade_df = pd.DataFrame({
            'Número de Alunos': alunos_por_cidade,
            'Idade Média': idade_media_cidade
        })
        st.dataframe(cidade_df)
        st.bar_chart(alunos_por_cidade)

        # Observação analítica
        st.markdown("""
        **🧠 Observação Analítica:**  
        As cidades com maior número de alunos refletem a concentração populacional e econômica.  
        **São Paulo**, por exemplo, é um centro industrial e financeiro que atrai moradores e, consequentemente, mais matrículas escolares.  
        Essa concentração pode indicar melhor acesso à educação, mas também desafios como superlotação e desigualdade regional.
        """)

    else:
        st.warning("A coluna 'Cidade de Correspondência' não foi encontrada no arquivo.")

    # --- Análise 2: Alunos por Origem ---
    st.header('De qual midia os alunos vieram?')
    if 'Origem' in df.columns:
        origem_contagem = df['Origem'].value_counts().head(5)
        idade_media_origem = df.groupby('Origem')['Idade'].mean().loc[origem_contagem.index]

        origem_df = pd.DataFrame({
            'Número de Alunos': origem_contagem,
            'Idade Média': idade_media_origem
        })
        st.dataframe(origem_df)
        st.bar_chart(origem_contagem)

        # Observação analítica
        st.markdown("""
        **🧠 Observação Analítica:**  
        As principais origens de descoberta do curso mostram o impacto de **mídias sociais, indicações e estratégias de marketing**.  
        Essa análise pode orientar investimentos em divulgação e reforçar os canais mais eficazes de captação de alunos.
        """)

    else:
        st.warning("A coluna 'Origem' não foi encontrada no arquivo.")
  
    # --- Análise 4: Distribuição por Escolaridade ---
    st.header('Distribuição por Escolaridade')
    if 'Escolaridade' in df.columns:
        escolaridade_contagem = df['Escolaridade'].value_counts()

        st.subheader('Tabela - Alunos por Escolaridade')
        st.dataframe(escolaridade_contagem)

        st.subheader('Gráfico - Alunos por Escolaridade')
        st.bar_chart(escolaridade_contagem)

        st.markdown("""
        **🧠 Observação Analítica:**  
        É importante destacar a presença significativa de alunos com **Ensino Superior Incompleto**.  
        Isso pode indicar um público que começou a graduação, mas não concluiu, o que pode ser sinal de dificuldades acadêmicas, financeiras ou de adaptação.  
        Reconhecer essa realidade é fundamental para desenvolver estratégias que **ajudem esses alunos a retomar e concluir seus estudos**, evitando evasão e desperdício de potencial.
        """)

    else:
        st.warning("A coluna 'Escolaridade' não foi encontrada no arquivo.")

    # --- Análise 5: Distribuição por Faixa Etária ---
    st.header('🎯 Distribuição por Faixa Etária')
    if 'Idade' in df.columns:
        bins = [0, 18, 25, 35, 45, 60, 100]
        labels = ['0-18', '19-25', '26-35', '36-45', '46-60', '60+']
        df['Faixa Etária'] = pd.cut(df['Idade'], bins=bins, labels=labels, right=False)

        faixa_etaria_contagem = df['Faixa Etária'].value_counts().sort_index()

        st.subheader('Tabela - Alunos por Faixa Etária')
        st.dataframe(faixa_etaria_contagem)

        st.subheader('Gráfico - Alunos por Faixa Etária')
        st.bar_chart(faixa_etaria_contagem)

        st.markdown("""
        **🧠 Observação Analítica:**  
        A faixa etária dos alunos fornece insights sobre o **momento de vida e necessidades** do público.  
        Uma maioria entre 19 e 35 anos, por exemplo, pode indicar busca por qualificação para o mercado de trabalho.  
        Já uma distribuição mais ampla reforça a **diversidade etária** e a importância da educação ao longo da vida.
        """)

    else:
        st.warning("A coluna 'Idade' não foi encontrada no arquivo.")

except FileNotFoundError:
    st.error("Arquivo 'alunos_pii_none.csv' não encontrado no diretório atual.")
